﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro_vodnik_
{
    internal static class y
    {
        public static ConsoleKeyInfo clavisha;
    }
}
