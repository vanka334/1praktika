﻿namespace pro_vodnik_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            diski.diskach();
        }
    }
}